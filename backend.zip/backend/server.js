const express = require("express");
const bodyParser = require("body-parser");
const mssql = require("mssql");
const cors = require("cors");
const Sentiment = require("sentiment");

const app = express();
app.use(bodyParser.json());
app.use(cors());

// Database configuration
const dbConfig = {
  user: "pranav",
  password: "@Aut0car",
  server: "my-feedback-server.database.windows.net",
  database: "FeedbackDB",
  options: {
    encrypt: true, // Azure SQL requires encryption
  },
};

// Initialize sentiment analysis
const sentiment = new Sentiment();

// Feedback submission route
app.post("/feedback", async (req, res) => {
  const { name, email, phone, feedback } = req.body;

  // Validation: Check if all required fields are provided
  if (!name || !email || !phone || !feedback) {
    return res.status(400).send({
      success: false,
      message: "All fields (name, email, phone, feedback) are required.",
    });
  }

  let sentimentScore = 0;
  let sentimentLabel = "Neutral"; // Default sentiment label

  try {
    // Analyze sentiment
    const sentimentResult = sentiment.analyze(feedback);
    sentimentScore = sentimentResult.score;

    // Determine sentiment label based on the score
    if (sentimentScore > 0) {
      sentimentLabel = "Positive";
    } else if (sentimentScore < 0) {
      sentimentLabel = "Negative";
    }

    // Establish connection to the database
    const pool = await mssql.connect(dbConfig);

    // SQL query to insert data into the FeedbackForm table
    const query = `
      INSERT INTO FeedbackForm (userName, email, phone, feedbackText, sentimentScore, sentimentLabel)
      VALUES (@name, @Email, @Phone, @Feedback, @SentimentScore, @SentimentLabel)
    `;

    await pool
      .request()
      .input("name", mssql.NVarChar, name)
      .input("Email", mssql.NVarChar, email)
      .input("Phone", mssql.NVarChar, phone)
      .input("Feedback", mssql.NVarChar, feedback)
      .input("SentimentScore", mssql.Int, sentimentScore)
      .input("SentimentLabel", mssql.NVarChar, sentimentLabel)
      .query(query);

    res.status(200).send({
      success: true,
      message: "Feedback saved successfully.",
    });
  } catch (err) {
    console.error("Error saving feedback:", err);

    res.status(500).send({
      success: false,
      message: "Error saving feedback. Please try again later.",
    });
  } finally {
    // Ensure the connection is closed
    mssql.close();
  }
});


// Fetch all feedback route
app.get("/all-feedback", async (req, res) => {
  try {
    const pool = await mssql.connect(dbConfig);

    const query = "SELECT * FROM FeedbackForm";
    const result = await pool.request().query(query);

    res.status(200).json(result.recordset);
  } catch (err) {
    console.error("Error fetching feedback:", err);
    res.status(500).send({ success: false, message: "Error fetching feedback." });
  } finally {
    mssql.close();
  }
});


// Start the server
app.listen(5000, () => {
  console.log("Server running on port 5000");
});
